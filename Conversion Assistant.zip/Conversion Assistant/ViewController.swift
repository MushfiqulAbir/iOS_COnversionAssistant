//
//  ViewController.swift
//  Multiple Converter
//
//  Created by Mushfiqul Islam on 5/31/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var unitConv: UIButton!
    @IBOutlet weak var massConv: UIButton!
    @IBOutlet weak var tempConv: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        unitConv.design()
        massConv.design()
        tempConv.design()
    }
    


}

extension UIButton{
    func design(){
        
        self.backgroundColor = UIColor.darkGray
        self.layer.cornerRadius = self.frame.height/2
        self.setTitleColor(UIColor.white, for: .normal)
        
        self.layer.shadowColor = UIColor.red.cgColor
        self.layer.shadowRadius = 6
        self.layer.shadowOpacity = 0.5
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        
    }
}

extension UITextField{
    func textDesign(){
        
        
        self.backgroundColor = UIColor.brown
        self.layer.cornerRadius = self.frame.height/2
        
        self.layer.shadowColor = UIColor.red.cgColor
        self.layer.shadowRadius = 6
        self.layer.shadowOpacity = 0.5
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        
        
        
    
}
}
