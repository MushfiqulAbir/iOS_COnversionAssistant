//
//  TemperatureViewController.swift
//  Multiple Converter
//
//  Created by Mushfiqul Islam on 5/28/21.
//

import UIKit

class TemperatureViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    @IBoutlet We
    
    func toFarenhite(){
        
    }
    


}
