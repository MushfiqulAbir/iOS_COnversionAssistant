//
//  MassViewController.swift
//  Multiple Converter
//
//  Created by Mushfiqul Islam on 5/31/21.
//

import UIKit

class MassViewController: UIViewController {

    @IBOutlet weak var kilogramsText: UITextField!
    @IBOutlet weak var kilogramsResult: UILabel!
    
    @IBOutlet weak var poundsText: UITextField!
    @IBOutlet weak var poundsResult: UILabel!
    
    
    @IBOutlet weak var ounceText: UITextField!
    @IBOutlet weak var ounceResult: UILabel!
    
    
    @IBOutlet weak var tonText: UITextField!
    @IBOutlet weak var tonResult: UILabel!
    
    
    
    @IBOutlet weak var poundButton: UIButton!
    @IBOutlet weak var kilogramButton: UIButton!
    @IBOutlet weak var pButton: UIButton!
    @IBOutlet weak var lbButtontwo: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        poundButton.design()
        kilogramButton.design()
        pButton.design()
        lbButtontwo.design()
        homeButton.design()
        
        kilogramsText.textDesign()
        poundsText.textDesign()
        ounceText.textDesign()
        tonText.textDesign()

        
    }
    
    //kg to lb conversion
    
    @IBAction func convertToPounds(_ sender: Any) {
        
        let kg = Double(kilogramsText.text!)
        let lb = kg! * 2.205
        
        let rounds = Double(round(100 * lb)/100)
        
        kilogramsResult.text = "In Pounds(lb): \(rounds)"
    }
    
    
    //lb to kg conversion
    
    @IBAction func convertToKg(_ sender: Any) {
        
        let lb = Double(poundsText.text!)
        let kg = lb! / 2.205
        
        let rounds = Double(round(100 * kg)/100)
        
        poundsResult.text = "In Kilograms(kg): \(rounds)"
    }
    
    
    //ounce to pounds
    
    @IBAction func convertTolb(_ sender: Any) {
        
        let oz = Double(ounceText.text!)
        let lb = oz! / 16
        
        let rounds = Double(round(100 * lb)/100)
        
        ounceResult.text = "In Pounds(lb): \(rounds)"
    }
    
    //Ton to Pounds
    
    
    @IBAction func conertToLb(_ sender: Any) {
        
        let ton = Double(tonText.text!)
        let lb = ton! * 2000
        
        let rounds = Double(round(100 * lb)/100)
        
        tonResult.text = "In Pounds(lb): \(rounds)"
    }
    
    
    
    
   

}
