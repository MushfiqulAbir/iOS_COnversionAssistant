//
//  UnitViewController.swift
//  Multiple Converter
//
//  Created by Mushfiqul Islam on 5/28/21.
//

import UIKit

class UnitViewController: UIViewController {

    @IBOutlet weak var kilometersText: UITextField!
    @IBOutlet weak var kilometerResult: UILabel!
    
    @IBOutlet weak var milesText: UITextField!
    @IBOutlet weak var milesResult: UILabel!
    
    @IBOutlet weak var meterText: UITextField!
    @IBOutlet weak var meterResult: UILabel!
    
    @IBOutlet weak var centimeterText: UITextField!
    @IBOutlet weak var centimeterResult: UILabel!
    
    @IBOutlet weak var milesButton: UIButton!
    @IBOutlet weak var kilometersButton: UIButton!
    @IBOutlet weak var centimeterButton: UIButton!
    @IBOutlet weak var meterButton: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        milesButton.design()
        kilometersButton.design()
        centimeterButton.design()
        meterButton.design()
        homeButton.design()
        
        kilometersText.textDesign()
        milesText.textDesign()
        meterText.textDesign()
        centimeterText.textDesign()
        
      
    }
    
    //code for kilometers to miles
    
    @IBAction func convertToMiles(_ sender: Any) {
        
        let kilo = Double(kilometersText.text!)
        let miles = kilo! / 1.609
        
        //printing 2 deciaml values
        
        let rounds = Double(round(100 * miles)/100)
        
        
        kilometerResult.text = "In miles: \(rounds)"
        
    }
    
    //code for miles to kilometers
    
    
    @IBAction func convertToKilometers(_ sender: Any) {
        
        let miles = Double(milesText.text!)
        let kilometer = miles! * 1.609
        
        //printing 2 deciaml values
        
        let rounds = Double(round(100 * kilometer)/100)
        
        milesResult.text = "In Kilometers: \(rounds)"
    }
    
    
    //code for meter to centimeter
    
    @IBAction func convertTocentiMeter(_ sender: Any) {
        
        let meter = Double(meterText.text!)
        let centiMeter = meter! * 100
        
        //printing 2 deciaml values
        
        let rounds = Double(round(100 * centiMeter)/100)
        
        meterResult.text = "In Centimeter: \(round(rounds))"
        
    }
    
    
    //code for centimeters to meters
    
    @IBAction func convertToMeters(_ sender: Any) {
        
        let centimeters = Double(centimeterText.text!)
        let meters = centimeters! / 100
        
        //printing 2 deciaml values
        
        let rounds = Double(round(100 * meters)/100)
        
        centimeterResult.text = "In meter: \(rounds)"
        
    }
    
    

 

}
