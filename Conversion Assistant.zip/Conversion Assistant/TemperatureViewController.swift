//
//  TemperatureViewController.swift
//  Multiple Converter
//
//  Created by Mushfiqul Islam on 5/28/21.
//

import UIKit

class TemperatureViewController: UIViewController {
    

    @IBOutlet weak var celcius: UITextField!
    @IBOutlet weak var farenhiet: UITextField!
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var result2: UILabel!
    
    @IBOutlet weak var convertButton: UIButton!
    @IBOutlet weak var secondConvert: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        convertButton.design()
        secondConvert.design()
        homeButton.design()
        
        celcius.textDesign()
        farenhiet.textDesign()
        
        
        
    }
    
    //celcius to farenhiet
    
    @IBAction func convert(_ sender: Any) {
        
        
        
        var celciusD = Double(celcius.text!)
        let far = Double ( celciusD! * 1.8) + 32
        
        let rounds = Double(round(100 * far)/100)
        
        result.text = "In farenheit: \(rounds)"
        
        
    }
    
    //Farenhiet to celcius
    
    @IBAction func conver2(_ sender: Any) {
        
        var farenhietD = Double(farenhiet.text!)
        let celcius = Double( farenhietD! - 32 ) / 1.8
        
        let rounds = Double(round(100 * celcius)/100)
        
        result2.text = "In Celcius: \(rounds)"
    }
    
}


